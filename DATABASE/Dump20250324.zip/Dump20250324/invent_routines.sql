-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: invent
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `v_user`
--

DROP TABLE IF EXISTS `v_user`;
/*!50001 DROP VIEW IF EXISTS `v_user`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user` AS SELECT 
 1 AS `iUserID`,
 1 AS `sUserName`,
 1 AS `sEmail`,
 1 AS `sFullName`,
 1 AS `sRole`,
 1 AS `sImgUrl`,
 1 AS `sPassword`,
 1 AS `iStatus`,
 1 AS `dtCreate`,
 1 AS `iCreateBy`,
 1 AS `dtModify`,
 1 AS `iModifyBy`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_entry_rpt`
--

DROP TABLE IF EXISTS `v_entry_rpt`;
/*!50001 DROP VIEW IF EXISTS `v_entry_rpt`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_entry_rpt` AS SELECT 
 1 AS `sKode`,
 1 AS `sName`,
 1 AS `iType`,
 1 AS `sUoM`,
 1 AS `iSemester`,
 1 AS `iYear`,
 1 AS `iCondition1`,
 1 AS `iCondition2`,
 1 AS `iCondition3`,
 1 AS `iSumCondition`,
 1 AS `sDesc`,
 1 AS `iApproved`,
 1 AS `dtCreate`,
 1 AS `iCreateBy`,
 1 AS `dtModify`,
 1 AS `iModifyBy`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_entry_trans`
--

DROP TABLE IF EXISTS `v_entry_trans`;
/*!50001 DROP VIEW IF EXISTS `v_entry_trans`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_entry_trans` AS SELECT 
 1 AS `sKode`,
 1 AS `sName`,
 1 AS `iType`,
 1 AS `sUoM`,
 1 AS `iSemester`,
 1 AS `iYear`,
 1 AS `iCondition1`,
 1 AS `iCondition2`,
 1 AS `iCondition3`,
 1 AS `sDesc`,
 1 AS `dtCreate`,
 1 AS `iCreateBy`,
 1 AS `dtModify`,
 1 AS `iModifyBy`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_user`
--

/*!50001 DROP VIEW IF EXISTS `v_user`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user` AS select `b`.`iUserID` AS `iUserID`,`b`.`sUserName` AS `sUserName`,`b`.`sEmail` AS `sEmail`,`b`.`sFullName` AS `sFullName`,`a`.`sRole` AS `sRole`,`b`.`sImgUrl` AS `sImgUrl`,`c`.`sPassword` AS `sPassword`,`a`.`iStatus` AS `iStatus`,`a`.`dtCreate` AS `dtCreate`,`a`.`iCreateBy` AS `iCreateBy`,`a`.`dtModify` AS `dtModify`,`a`.`iModifyBy` AS `iModifyBy` from ((`tudt01` `a` join `tumx01` `b` on((`a`.`iUserID` = `b`.`iUserID`))) join `tumx02` `c` on((`a`.`iUserID` = `c`.`iUserID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_entry_rpt`
--

/*!50001 DROP VIEW IF EXISTS `v_entry_rpt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_entry_rpt` AS with `rankeddata` as (select `a`.`sKode` AS `sKode`,`b`.`sName` AS `sName`,if((`b`.`iType` = 1),'Prasarana','Sarana') AS `iType`,`b`.`sUoM` AS `sUoM`,if((`a`.`iSemester` = 1),'Ganjil','Genap') AS `iSemester`,`a`.`iYear` AS `iYear`,`a`.`iCondition1` AS `iCondition1`,`a`.`iCondition2` AS `iCondition2`,`a`.`iCondition3` AS `iCondition3`,`a`.`iApproved` AS `iApproved`,`a`.`sDesc` AS `sDesc`,`a`.`dtCreate` AS `dtCreate`,`a`.`iCreateBy` AS `iCreateBy`,`a`.`dtModify` AS `dtModify`,`a`.`iModifyBy` AS `iModifyBy`,row_number() OVER (PARTITION BY `a`.`sKode`,`a`.`iSemester`,`a`.`iYear` ORDER BY `a`.`dtCreate` desc )  AS `row_num` from (`tudt02` `a` join `tumx03` `b` on(((`a`.`sKode` = `b`.`sKode`) and (`b`.`iStatus` = 1))))) select `rankeddata`.`sKode` AS `sKode`,`rankeddata`.`sName` AS `sName`,`rankeddata`.`iType` AS `iType`,`rankeddata`.`sUoM` AS `sUoM`,`rankeddata`.`iSemester` AS `iSemester`,`rankeddata`.`iYear` AS `iYear`,sum(`rankeddata`.`iCondition1`) AS `iCondition1`,sum(`rankeddata`.`iCondition2`) AS `iCondition2`,sum(`rankeddata`.`iCondition3`) AS `iCondition3`,sum(((`rankeddata`.`iCondition1` + `rankeddata`.`iCondition2`) + `rankeddata`.`iCondition3`)) AS `iSumCondition`,max((case when (`rankeddata`.`row_num` = 1) then `rankeddata`.`sDesc` end)) AS `sDesc`,max(`rankeddata`.`iApproved`) AS `iApproved`,max(`rankeddata`.`dtCreate`) AS `dtCreate`,max(`rankeddata`.`iCreateBy`) AS `iCreateBy`,max(`rankeddata`.`dtModify`) AS `dtModify`,max(`rankeddata`.`iModifyBy`) AS `iModifyBy` from `rankeddata` group by `rankeddata`.`sKode`,`rankeddata`.`iSemester`,`rankeddata`.`iYear`,`rankeddata`.`iApproved` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_entry_trans`
--

/*!50001 DROP VIEW IF EXISTS `v_entry_trans`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_entry_trans` AS select `a`.`sKode` AS `sKode`,`b`.`sName` AS `sName`,`b`.`iType` AS `iType`,`b`.`sUoM` AS `sUoM`,`a`.`iSemester` AS `iSemester`,`a`.`iYear` AS `iYear`,`a`.`iCondition1` AS `iCondition1`,`a`.`iCondition2` AS `iCondition2`,`a`.`iCondition3` AS `iCondition3`,`a`.`sDesc` AS `sDesc`,`a`.`dtCreate` AS `dtCreate`,`a`.`iCreateBy` AS `iCreateBy`,`a`.`dtModify` AS `dtModify`,`a`.`iModifyBy` AS `iModifyBy` from (`tudt02` `a` join `tumx03` `b` on((`a`.`sKode` = `b`.`sKode`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-24  4:27:13
